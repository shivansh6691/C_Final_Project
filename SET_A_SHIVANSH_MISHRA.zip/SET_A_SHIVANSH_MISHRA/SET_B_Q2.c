#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char child[10][100],father[10][100],str[100];
void main ()
{
	FILE *p;
	p=fopen("file.txt","r");
	int num=5;
	int flag;
	printf("Enter Grand_Father Name :\n");
	scanf("%s",str);

for(int i=0;i<num;i++)
{
	fscanf(p,"%s",child[i]);
	fscanf(p,"%s",father[i]);
	if(strcmp(str,father[i]) == 0)
	flag = i;
}
int c = 0;
for(int i=0;i<num;i++)
{
	if(strcmp(child[flag],father[i]) == 0)
	c+=1;
}
printf("Number of Grand_Children = %d\n",c);
fclose(p);
}
