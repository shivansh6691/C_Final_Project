#include<stdio.h>    
#include<stdlib.h>  
void main()
{  
    int str[20];
    int num,i,flag=0;    
    printf("Enter a number : ");    
    scanf("%d",&num);  

    for(i=0;num>0;i++)    
    {    
        str[i]=num%2;    
        num=num/2;    
    }    
    printf("\nBefore_Reverse -->>:  ");    
    for(i=i-1;i>=0;i--)    
    {    
        printf("%d",str[i]);
        flag+=1;
    }
    printf("\nAfter_Reverse -->> :  "); 
    for(i=0;i<flag;i++)    
    {    
        printf("%d",str[i]);    
    } 
}
